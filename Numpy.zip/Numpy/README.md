# Lab 4 requirements
```bash
pip install matplotlib plotly
```
# Lab5 requirements
```bash
pip install numpy
```